/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;

public class kesalahan_pendeklarasian_variabel {
    public static void main(String[] args) {
        
        // Pendeklarasian yang Benar
        boolean gameOver=false;
        int students=50, classes=3;
        double sales_tax;
        sales_tax=1.2;
        short number1;
        number1=12;
        
        //Pendeklarasian yang Salah 
        // Karakter pertama dari variabel hanya boleh berupa huruf dan underscore ( _ )
        int 2beOrNot2be; 
        // variabel tidak boleh ada spasi
        float price index; 
        // tidak boleh ada tanda petik atas pada variabel
        double lastYear'sPrice; 
        // variabel harus selain kyword
        long class; 
      
    }
}
