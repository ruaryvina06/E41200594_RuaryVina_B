/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;
class orang{
    String Name;
    int Age;
    public void set(String Name, int Age){
     this.Name = Name;
     this.Age = Age;
    }  
    public String getName(){
        return Name;
    }
    public void setName(String Name){
        this.Name = Name;
    }
    public int Age(){
        return Age;
    }
    public void setAge(int Age){
        this.Age = Age;
    }
}
public class managingpeople {
    public static void main(String[] args) {
       
        orang p1 = new orang();
        orang p2 = new orang();
        p1.set("Ruary", 19);
        p2.set("Vina", 16);
        
        if (p1.Age()==p2.Age) {
            System.out.println(p1.getName()+ " is the same age as "+p2.getName());
        } else{
             System.out.println(p1.getName()+ " is not the same age as "+p2.getName());
        }
    }
}
