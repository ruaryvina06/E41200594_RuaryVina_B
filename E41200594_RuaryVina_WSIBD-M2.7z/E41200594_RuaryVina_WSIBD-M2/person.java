/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;
class Person1{
    String fNama;
    String lNama;
    int stuId;
    String stuStatus;
    
    public void set(String fNama, String lNama, int stuId, String stuStatus){
        this.fNama = fNama;
        this.lNama = lNama;
        this.stuId = stuId;
        this.stuStatus = stuStatus;
    }
    public void tampil(){
        System.out.println("====== Data Murid =====");
        System.out.println("Student Name : " +fNama + " "+lNama);
        System.out.println("Student ID : " + stuId);
        System.out.println("Student Status : " + stuStatus);
    }
}
public class person {
    public static void main(String[] args) {
        Person1 student = new Person1();
        student.set("Lisa", "Palombo", 123456789, "Active");
        student.tampil();
    }
}
